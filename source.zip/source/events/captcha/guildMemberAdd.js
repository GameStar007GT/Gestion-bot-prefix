const Canvas = require("canvas");
const { Astroia } = require("../../structures/client/index");

module.exports = {
    name: "guildMemberAdd",
    /**
     * @param {Astroia}  client
     * @param {Discord.GuildMember} member
     */
    async run(client, member) {
        function generateCaptcha() {
            let text = "";
            const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (let i = 0; i < 5; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        }

        const config = client.db.get(`captcha_${member.guild.id}`);
console.log("Config du captcha récupérée :", config); 
if (!config || config.status === undefined) {
    console.log("La configuration du captcha n'a pas été correctement définie.");
    return;
}

const channel = member.guild.channels.cache.get(config.channel[0]);
if (!channel) {
    console.log("Le canal configuré pour le captcha n'a pas été trouvé.");
    return;
}


        if (member.bot) {
            console.log("Le membre est un bot, le captcha ne s'applique pas.");
            return;
        }

        const canvas = Canvas.createCanvas(700, 250);
        const ctx = canvas.getContext("2d");
        const background = await Canvas.loadImage("./images/captcha-background.jpg", { format: "jpg" });
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
        let captchaText = generateCaptcha();
        console.log("Captcha généré :", captchaText);

        ctx.textAlign = "center";
        ctx.font = "100px sans-serif";
        ctx.fillStyle = "#ffffff";
        ctx.fillText(captchaText, canvas.width / 2, canvas.height / 2 + 20);

        let fake1 = generateCaptcha();
        let fake2 = generateCaptcha();
        let buttons = [
            { type: 2, style: 1, label: fake1, custom_id: fake1 },
            { type: 2, style: 1, label: fake2, custom_id: fake2 },
            { type: 2, style: 1, label: captchaText, custom_id: captchaText }
        ];
        buttons = buttons.sort(() => Math.random() - 0.5);

        console.log("Envoi du captcha au membre...");
        const msg = await channel.send({
            content: `Bienvenue sur ${member.guild.name}, ${member}! S'il vous plaît vérifier vous en appuyant sur la bonne réponse.`,
            components: [{
                type: 1,
                components: buttons
            }],
            files: [{ attachment: canvas.toBuffer(), name: "captcha.jpg" }]
        });

        const collector = msg.createMessageComponentCollector({ filter: (i) => i.user.id === member.id, time: 300000, max: 1 });

        collector.on("collect", async (collected) => {
            if (collected.customId === captchaText) {
                collected.deferUpdate();
                msg.delete();
                member.roles.add(config.role);
                console.log("Captcha réussi, rôle ajouté au membre.");
            } else {
                collected.deferUpdate();
                msg.delete();
                member.kick();
                console.log("Captcha échoué, membre kické.");
            }
        });

        collector.on("end", (collected, reason) => {
            if (reason === 'time') {
                console.log("Temps de collecte écoulé pour le captcha, membre kické.");
                msg.delete();
                member.kick();
            }
        });
    }
};
