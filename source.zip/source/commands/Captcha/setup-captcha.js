const Discord = require('discord.js');
const Astroia = require('../../structures/client');
const ms = require('ms')
module.exports = {
  name: "captcha",
  aliases: ["setup-captcha", "setupcaptcha", "captcha-setup", "captchasetup"],
  description: "Configure le captcha.",
  /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {

      let pass = false;
      let staff = client.staff;
      if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
          if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
      } else {
          pass = true;
      }

      if (pass === false) {
          if (client.noperm && client.noperm.trim() !== '') {
              return message.channel.send(client.noperm);
          } else {
              return;
          }
      }
    let msg = await message.reply({ content: 'Chargement en cours...' })
    async function update() {
      const db = client.db.get(`captcha_${message.guild.id}`) || {
        status: false,
        role: [],
        channel: []
      }
      const status = db?.status === true ? '🟢' : '🔴';
      const role = db?.role;
      const channel = db?.channel
      const rolename = role ? role.map(roleId => message.guild.roles.cache.get(roleId)?.name || "Inconnu") : [];
      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Captcha')
        .addFields(
          { name: 'Status :', value: `\`\`\`yml\n${status}\`\`\`` },
          { name: "Rôle à donner à la réussite :", value: `\`\`\`yml\n${rolename.join(', ') || "Aucun rôle défini"}\`\`\`` },
          { name: "Channel ou sera poster le captcha :", value: `\`\`\`yml\n${channel}\`\`\`` },
        )

      const rowbutton = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId(`captcha_active_` + message.id)
            .setEmoji(db?.status === true ? '🟢' : '🔴')
            .setStyle(db?.status === true ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Danger),
          new Discord.ButtonBuilder()
            .setCustomId(`captcha_role_` + message.id)
            .setLabel('Ajouter / Retire des rôles')
            .setStyle(Discord.ButtonStyle.Success),
            new Discord.ButtonBuilder()
            .setCustomId(`captcha_channel_` + message.id)
            .setLabel('Le channel')
            .setStyle(Discord.ButtonStyle.Success),
          new Discord.ButtonBuilder()
            .setCustomId(`captcha_reset_` + message.id)
            .setLabel('Reset')
            .setStyle(Discord.ButtonStyle.Danger)
        )


      return msg.edit({ embeds: [embed], components: [rowbutton], content: null })
    }
    update()

    const collector = message.channel.createMessageComponentCollector({ filter: m => m.user.id == message.author.id, componentType: Discord.ComponentType.Button, time: ms("2m") })
    collector.on("collect", async (i) => {
      if (i.customId === `captcha_role_${message.id}`) {
        const rowrole = new Discord.RoleSelectMenuBuilder()
          .setCustomId('captcha_role_select_' + message.id)
          .setMaxValues(1)
          .setMaxValues(25);
        const row = new Discord.ActionRowBuilder()
          .addComponents(rowrole);
        const rowbutton = new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.ButtonBuilder()
              .setCustomId('captcha_role_retour_' + message.id)
              .setStyle(Discord.ButtonStyle.Danger)
              .setEmoji('◀')
          );
        i.update({ components: [row, rowbutton], embeds: [], content: "Merci de choisir les rôles a ajouter ou a supprimer" })
      }

    })

    client.on('interactionCreate', async (i) => {
      if (i.user.id !== message.author.id) return i.reply({ content: await client.lang('noperminterac'), ephemeral: true });
      if (i.customId === `captcha_role_retour_${message.id}`) {
        update()
      } else if (i.customId === `captcha_active_${message.id}`) {
        let db = client.db.get(`captcha_${message.guild.id}`);
        const currentStatus = db?.status;
        const newStatus = currentStatus === null ? true : !currentStatus;
        db = { ...db, status: newStatus };
        client.db.set(`captcha_${message.guild.id}`, db);
        const status = db?.status === true ? 'Le status a été activiter avec succès' : 'Le status a été déactiviter avec succès';
        const reply = await i.reply({ content: status, ephemeral: true });
        setTimeout(async () => {
          await reply.delete();
      }, ms('1s')); 
        update()

      } else if (i.customId === `captcha_reset_${message.id}`) {
       let reply = await i.reply({content: '`✅` les paramètres ont était bien reset',ephemeral: true})
        client.db.delete(`captcha_${message.guild.id}`);
        setTimeout(async () => {
          await reply.delete();
      }, ms('1s')); 
        update()
      } else if (i.customId === `captcha_role_select_${message.id}`) {
        const selectedRoles = i.values;
    
        let roledb = client.db.get(`captcha_${message.guild.id}`);
        if (!roledb) {
          roledb = {
            status: false,
            role: [],
            channel: []
          };
        }

        const existingRoles = roledb.role || [];

        let rolesAdded = 0;
        let rolesRemoved = 0;
        let invalidRoles = 0;
        let inaccessibleRoles = 0;

        for (const roleId of selectedRoles) {
          const role = message.guild.roles.cache.get(roleId);

          if (!role) {
            invalidRoles++;
            continue;
          }

          if (role.managed) {
            inaccessibleRoles++;
            continue;
          }

          if (!role.editable) {
            inaccessibleRoles++;
            continue;
          }

          if (existingRoles.includes(roleId)) {
            const updatedRoles = existingRoles.filter(id => id !== roleId);
            roledb.role = updatedRoles;
            client.db.set(`captcha_${message.guild.id}`, roledb);
            rolesRemoved++;
          } else {
            existingRoles.push(roleId);
            roledb.role = existingRoles;
            client.db.set(`captcha_${message.guild.id}`, roledb);
            rolesAdded++;
          }
        }

        let response = '';

        if (rolesAdded > 0) {
          response += `Rôles Ajoutés : \`${rolesAdded} rôles\`\n`;
        }
        if (rolesRemoved > 0) {
          response += `Rôles Retirés : \`${rolesRemoved} rôles\`\n`;
        }
        if (invalidRoles > 0) {
          response += `Rôles Invalides : \`${invalidRoles} rôles\`\n`;
        }
        if (inaccessibleRoles > 0) {
          response += `Rôles Inaccessibles : \`${inaccessibleRoles} rôles\`\n`;
        }
        console.log('Response:', response);
        i.reply({ content: response, ephemeral: true });
        update()
      }
    });


    collector.on('end', () => {
      msg.edit({ components: [] });
    });
    const collectorchannel = message.channel.createMessageComponentCollector({ filter: m => m.user.id == message.author.id, componentType: Discord.ComponentType.Button, time: ms("2m") })
    collectorchannel.on("collect", async (i) => {
      if (i.customId === `captcha_channel_${message.id}`) {



        const rowchannel = new Discord.ChannelSelectMenuBuilder()
          .setCustomId('captcha_channel_select_' + message.id)
          .setMaxValues(1)
          .setMaxValues(1)
          .setChannelTypes(0);
    
 
        const row = new Discord.ActionRowBuilder().addComponents(rowchannel);
        const rowbutton = new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.ButtonBuilder()
              .setCustomId('captcha_channel_retour_' + message.id)
              .setStyle(Discord.ButtonStyle.Danger)
              .setEmoji('◀')
          );
        i.update({ components: [row, rowbutton], embeds: [], content: "Merci de choisir le canal où sera posté le captcha !" });
      }
    });
    client.on('interactionCreate', async (i) => {
        if (i.user.id !== message.author.id) return i.reply({ content: await client.lang('noperminterac'), ephemeral: true });
      
        if (i.customId === `captcha_channel_retour_${message.id}`) {
          update();
        } else if (i.customId === `captcha_channel_select_${message.id}`) {
          const selectedChannel = i.values[0]; 
    
      
          let channeldb = client.db.get(`captcha_${message.guild.id}`);
          if (!channeldb) {
            channeldb = {
              status: false,
              role: [],
              channel: []
            };
          }
      
          const existingChannel = channeldb.channel || [];
      
          let channelAdded = 0;
          let channelRemoved = 0;
          let invalidChannel = 0;
          let inaccessibleChannel = 0;
      
          const channel = message.guild.channels.cache.get(selectedChannel);
         
      
          if (!channel) {
            invalidChannel++;
           
          } else {
            const member = message.guild.members.cache.get(i.user.id);
            if (!channel.permissionsFor(member.id).has('SEND_MESSAGES')) {
              inaccessibleChannel++;
            } else {
              if (existingChannel.includes(selectedChannel)) {
                const updatedChannel = existingChannel.filter(id => id !== selectedChannel);
                channeldb.channel = updatedChannel;
                client.db.set(`captcha_${message.guild.id}`, channeldb);
                channelRemoved++;
              } else {
                existingChannel.push(selectedChannel);
                channeldb.channel = existingChannel;
                client.db.set(`captcha_${message.guild.id}`, channeldb);
                channelAdded++;
              }
            }
          }
      
          let response = '';
      
          if (channelAdded > 0) {
            response += `Channel Ajouté : \`${channelAdded} channel\`\n`;
          }
          if (channelRemoved > 0) {
            response += `Channel Retiré : \`${channelRemoved} channel\`\n`;
          }
          if (invalidChannel > 0) {
            response += `Channel Invalide : \`${invalidChannel} channel\`\n`;
          }
          if (inaccessibleChannel > 0) {
            response += `Channel Inaccessible : \`${inaccessibleChannel} channel\`\n`;
          }
      
          console.log('Response:', response);
      
          i.reply({ content: response, ephemeral: true });
          update();
        }
      });
      
  }
}